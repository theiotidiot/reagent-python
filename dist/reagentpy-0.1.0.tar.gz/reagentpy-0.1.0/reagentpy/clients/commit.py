from reagentpy.clients import ReagentClient, ReagentResponse

class CommitClient(ReagentClient):
    def __init__(self):
        super().__init__()
