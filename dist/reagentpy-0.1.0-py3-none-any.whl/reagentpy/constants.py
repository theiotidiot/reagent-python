VERSION = "0.1.0"
REAGENTPY_USER_AGENT = "reagentpy"
REAGENT_BASE_URL = "https://api.reagentanalytics.com/v1"